package hotel.reservation;

public class User {
    private int id;
    private String email;
}
