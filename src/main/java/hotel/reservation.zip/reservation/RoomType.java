package hotel.reservation;

public enum RoomType {
    premium, ordinary;
}
