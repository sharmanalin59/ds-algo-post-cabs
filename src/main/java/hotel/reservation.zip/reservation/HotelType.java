package hotel.reservation;

public enum HotelType {

}
